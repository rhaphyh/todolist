angular.module('app', ['ngRoute'])
    //---------------
    // Services
    //---------------
    .factory('Todos', function(){
      return [
        { name: 'AngularJS Directives', completed: true, note: 'add notes...' },
        { name: 'Data binding', completed: false, note: 'add notes...' },
        { name: '$scope', completed: true, note: 'add notes...' },
        { name: 'Controllers and Modules', completed: true, note: 'add notes...' },
        { name: 'Templates and routes', completed: true, note: 'add notes...' },
        { name: 'Filters and Services', completed: false, note: 'add notes...' },
        { name: 'Get started with Node/ExpressJS', completed: true, note: 'add notes...' },
        { name: 'Setup MongoDB database', completed: false, note: 'add notes...' },
        { name: 'Be awesome!', completed: false, note: 'add notes...' }
      ];
    })

    //---------------
    // Directives
    //---------------

    .directive('ngBlur', function(){
      return function(scope, elem, attrs){
          elem.bind('blur', function(){
            scope.$apply(attrs.ngBlur);
          })
      }
    })

    //---------------
    // Controllers
    //---------------
    .controller('TodoController', function ($scope, $location, Todos, filterFilter) {
    
      
      $scope.todos = Todos;

      $scope.$watch('todos',function(){
          $scope.remaining = filterFilter($scope.todos,{completed:false}).length;
          $scope.allchecked = !$scope.remaining;
      }, true);

      
      if( $location.path() == '' ) $location.path('/');
      $scope.location = $location;
      $scope.$watch('location.path()', function(path){
        $scope.statusFilter = (path == '/active') ? {completed: false} : (path == '/done') ? {completed: true} : '';
      })
      

      $scope.removeTodo = function(index){
        $scope.todos.splice(index,1);
      }

      $scope.addTodo = function(){
        $scope.todos.push({
          name: $scope.newtodo,
          completed: false
        })
        $scope.newtodo = '';
      }

      $scope.checkAllTodo = function(allchecked){
        $scope.todos.forEach(function(todo){
          todo.completed = allchecked;
        })
      }

      $scope.editTodo = function(todo){
        todo.editing = false;
      }


    });

  